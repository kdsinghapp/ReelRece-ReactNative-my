// NativeScreenManager.js
import { NativeModules } from "react-native";

const { NativeScreenManager } = NativeModules;

export default NativeScreenManager;
