// groupApi.ts

import axiosInstance from "@redux/Api/axiosInstance";
import { Group, PaginatedResponse } from "@types/api.types";

interface GroupInvitation extends Group {
  invited_at?: string;
  invited_by?: string;
}


export const getPendingGroupInvites = async (token: string) => {
  try {
    const response = await axiosInstance.get('/group/pending-invitations', {
      headers: {
        Authorization: `Token ${token}`,
      },
    });

     return response.data;
  } catch (error) {
     throw error;
  }
};


export const respondToGroupInvitation = async (
  token: string,
  groupId: string,
  accepted: boolean
): Promise<{ success: boolean; message?: string }> => {
  try {
    const response = await axiosInstance.put(
      'group/accept-invitation',
      {
        group_id: groupId,
        invitation_accepted: accepted ? 'yes' : 'no',
      },
      {
        headers: {
          Authorization: `Token ${token}`,
        },
      }
    );
     return response.data;
  } catch (error: unknown) {
     throw error;
  }
};

// import { getPendingGroupInvites } from '@redux/Api/groupApi';
// import { useSelector } from 'react-redux';
// import { RootState } from '@redux/store';

// const token = useSelector((state: RootState) => state.auth.token);
// const [pendingInvites, setPendingInvites] = useState([]);

// useEffect(() => {
//   const fetchInvites = async () => {
//     try {
//       const data = await getPendingGroupInvites(token);
//       setPendingInvites(data.results); // or entire `data` if pagination needed
//     } catch (error) {
 //     }
//   };

//   if (token) {
//     fetchInvites();
//   }
// }, [token]);
