import { NativeModules, Platform } from 'react-native';
import RNFS from 'react-native-fs';

const { VideoCacheModule } = NativeModules;

// 🧮 Folder size calculate karne ke liye helper
const getFolderSize = async (folderPath) => {
  try {
    const files = await RNFS.readDir(folderPath);
    let total = 0;
    for (const file of files) {
      if (file.isFile()) {
        const stat = await RNFS.stat(file.path);
        total += Number(stat.size);
      } else if (file.isDirectory()) {
        total += await getFolderSize(file.path);
      }
    }
    return total;
  } catch (e) {
     return 0;
  }
};

/**
 * 🧹 Master Controller — Clear Video Cache
 * 
 * @param {"all" | "limit"} mode - "all" = pura clear, "limit" = size-based (3MB rakhna)
 */
export const clearVideoCache = async (mode = "all") => {
  try {
    const cacheDir = RNFS.CachesDirectoryPath;
     // 🔍 Before clear size
    const before = await getFolderSize(cacheDir);
 
    // 🔧 Cache files fetch
    const files = await RNFS.readDir(cacheDir);
    const fileList = [];

    for (const file of files) {
      const stat = await RNFS.stat(file.path);
      fileList.push({
        path: file.path,
        size: Number(stat.size),
        mtime: stat.mtime ? new Date(stat.mtime).getTime() : 0,
      });
    }

    // 🗂️ Sort by last modified (newest first)
    fileList.sort((a, b) => b.mtime - a.mtime);

    if (mode === "all") {
      // 🔥 Delete all cache files
      for (const file of fileList) {
        await RNFS.unlink(file.path);
      }
     } else if (mode === "limit") {
      // 📏 Keep only 3MB
      let keptSize = 0;
 
      for (const file of fileList) {
        if (keptSize < 30 * 1024 * 1024) {
          keptSize += file.size;
         } else {
          await RNFS.unlink(file.path);
         }
      }
     }

    // 🧩 Clear Native Player cache
    if (VideoCacheModule && typeof VideoCacheModule.clearCache === 'function') {
      await VideoCacheModule.clearCache();
     }

    // 📉 After clear size
    const after = await getFolderSize(cacheDir);
    const diff = before - after;
   } catch (error) {
   }
};
 