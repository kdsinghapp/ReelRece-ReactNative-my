import { API_BASE_URL, API_ENDPOINTS } from '@config/api.config';
import axiosInstance from './axiosInstance';
import { Use } from 'react-native-svg';
import { userBookMark } from './ProfileApi';

 
export const getUserFeed = async (
  token: string,
  type: "home" | "profile" | "otherprofile",
  username?: string,
  page: number = 1 
) => {
  try {
const url = API_BASE_URL + API_ENDPOINTS.USER.FEED;
     const queryParams: string[] = [];
    if (type === "otherprofile" && username) {
      queryParams.push(`username=${username}`);
    }
    // if (type === "profile") {
    //    queryParams.push("page=2");
    //   if (username) {
    //     queryParams.push(`username=${username}`);
    //   }
    // }
    if (queryParams.length > 0) {
      url += "?" + queryParams.join("&");
    }

    console.log("📡 URL Called:", url);

    const response = await axiosInstance.get(url, {
      headers: {
        Authorization: `Token ${token}`,
      },
    });

    return response.data;
  } catch (error) {
    console.error("❌ Error fetching user feed:", error);
    throw error;
  }
};


// export const getUserFeed = async (
//   token: string,
//   type: "home" | "profile" | "otherprofile",
//   username?: string,
//   page: number = 1
// ) => {
//   try {
// console.log(type ,"1111 type")

//     let url = "http://reelrecs.us-east-1.elasticbeanstalk.com/v1/user-feed";

//     const queryParams: string[] = [];

//     queryParams.push(`page=${page}`);

//     if (type === "otherprofile" && username) {
//       queryParams.push(`username=${username}`);
//     }
//      if (type === "profile" && username) {
//       queryParams.push(`username=${username}`);
//     }

//     if (queryParams.length > 0) {
//       url += "?" + queryParams.join("&");
//     }
//     console.log("B",   url);

//     const response = await axiosInstance.get(url, {
//       headers: {
//         Authorization: `Token ${token}`,
//       },
//     });
// console.log(response.data ,'response.data___fedddededata___here')
// console.log(response.data?.current_page ,'response__current___page__data')
//     return response.data;
//   } catch (error) {
//     console.error("❌ Error fetching user feed:", error);
//     throw error;
//   }
// };