import axios from 'axios';
import TokenService from '@services/TokenService';
import { getAxiosConfig } from '@config/api.config';

// ✅ Base configuration from centralized config
const axiosInstance = axios.create(getAxiosConfig());

// ✅ Define public endpoints that don't require authentication
const PUBLIC_ENDPOINTS = [
  '/login',
  '/signup',
  '/verify-email',
  '/confirm-email-code',
  '/reset-password',
  '/check-username',
  '/existing-user',
];

/**
 * Check if endpoint requires authentication
 */
const requiresAuth = (url?: string): boolean => {
  if (!url) return false;
  return !PUBLIC_ENDPOINTS.some(endpoint => url.includes(endpoint));
};

// Add request interceptor for token injection with race condition fix
axiosInstance.interceptors.request.use(
  async (config) => {
    const endpoint = config.url || 'unknown';
    const needsAuth = requiresAuth(endpoint);

    if (__DEV__) {
      // console.log('[DIAG] [Axios Interceptor] Request:', {
      //   url: endpoint,
      //   method: config.method?.toUpperCase(),
      //   requiresAuth: needsAuth,
      // });
    }

    // ✅ Skip auth for public endpoints
    if (!needsAuth) {
      if (__DEV__) {
        // console.log('[DIAG] [Axios Interceptor] Public endpoint, skipping auth');
      }
      return config;
    }

    // ✅ For protected endpoints: Wait for token or fail loudly
    try {
      // First try immediate token retrieval
      let token = await TokenService.getToken();

      // ✅ If no token, wait for it (with timeout)
      if (!token) {
        if (__DEV__) {
         }
        
        // Wait up to 5 seconds for token to become available
        token = await TokenService.waitForToken(50, 100); // 50 attempts * 100ms = 5 seconds
      }

      // ✅ CRITICAL: If still no token, FAIL LOUDLY instead of sending unauthenticated request
      if (!token) {
        const error = new Error(
          `❌ [Auth Required] No authentication token available for ${endpoint}. ` +
          `Please login first.`
        );
        (error as any).isAuthError = true;
        (error as any).code = 'NO_AUTH_TOKEN';
        (error as any).endpoint = endpoint;

        console.error('[DIAG] [Axios Interceptor] BLOCKING REQUEST - No token available:', {
          endpoint,
          method: config.method,
        });

        throw error; // ✅ Reject the request instead of sending it without auth
      }

      // ✅ Token available: Validate it's a string and add to headers
      if (typeof token !== 'string') {
        const error = new Error(
          `❌ [Auth Error] Token is not a string (type: ${typeof token}). ` +
          `This indicates a storage corruption issue.`
        );
      
        console.error('[DIAG] [Axios Interceptor] BLOCKING REQUEST - Token is not a string:', {
          endpoint,
          tokenType: typeof token,
          tokenValue: token,
        });
        
        throw error;
      }

      if (config.headers) {
        config.headers.Authorization = `Token ${token}`;
        
        if (__DEV__) {
          // console.log('[DIAG] [Axios Interceptor] ✅ Added auth header:', {
          //   endpoint,
          //   tokenPreview: token.length > 20 ? `${token.substring(0, 20)}...` : token,
          //   tokenLength: token.length,
          // });
        }
      }

      return config;

    } catch (error) {
      // If it's our auth error, re-throw it
      if ((error as any).isAuthError) {
        throw error;
      }

      // For other errors, log and fail loudly
      console.error('[DIAG] [Axios Interceptor] Error in token retrieval:', error);
      
      const authError = new Error(
        `❌ [Auth Error] Failed to retrieve token: ${(error as Error).message}`
      );
      (authError as any).isAuthError = true;
      (authError as any).code = 'TOKEN_RETRIEVAL_FAILED';
      (authError as any).originalError = error;
      
      throw authError;
    }
  },
  (error) => {
    console.error('[DIAG] [Axios Interceptor] Request error:', error);
    return Promise.reject(error);
  }
);

// Add response interceptor for debugging and error handling
axiosInstance.interceptors.response.use(
  (response) => {
    if (__DEV__) {
      // console.log('[DIAG] [Axios Response] ✅ Success:', {
      //   url: response.config?.url,
      //   status: response.status,
      //   statusText: response.statusText,
      // });
    }
    return response;
  },
  async (error) => {
    const status = error.response?.status;
    const url = error.config?.url;
    const hadAuthHeader = !!error.config?.headers?.Authorization;

    if (__DEV__) {
      console.error('[DIAG] [Axios Response] ❌ Error:', {
        url,
        status,
        statusText: error.response?.statusText,
        data: error.response?.data,
        message: error.message,
        hadAuthHeader,
        isAuthError: (error as any).isAuthError,
      });
    }

    // ✅ Enhanced 401 handling
    if (status === 401) {
      if (hadAuthHeader) {
        console.error(
          '[DIAG] [Axios] 🚨 401 UNAUTHORIZED with token present\n' +
          'Possible causes:\n' +
          '  1. Token is expired\n' +
          '  2. Token is invalid\n' +
          '  3. User session ended on backend\n' +
          'Action: User needs to re-login'
        );

        // Clear invalid token
        await TokenService.clearToken();

        // Add flag to error for UI to handle
        (error as any).tokenInvalid = true;
        (error as any).requiresReauth = true;
      } else {
        console.error(
          '[DIAG] [Axios] 🚨 401 UNAUTHORIZED without token\n' +
          'This should not happen if interceptor is working correctly!\n' +
          'Protected endpoint called without authentication.'
        );
        
        (error as any).noToken = true;
      }
    }

    // ✅ Handle network errors
    if (error.message === 'Network Error' || error.code === 'ECONNABORTED') {
      console.error('[DIAG] [Axios] 📡 Network error - check internet connection');
      (error as any).isNetworkError = true;
    }

    return Promise.reject(error);
  }
);

export default axiosInstance;

// ✅ Re-export commonly used config values from centralized config
export { BASE_IMAGE_URL, buildImageUrl, API_BASE_URL } from '@config/api.config';
