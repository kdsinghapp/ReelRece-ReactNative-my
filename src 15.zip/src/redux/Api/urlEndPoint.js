export const urlEndPoint = {
    suggest_Friends: "suggest-friends",
    movie_metadata:"movie-metadata",
}