import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  requireNativeComponent,
  View,
  Image,
  Animated,
  Platform,
  DeviceEventEmitter,
  ViewStyle,
  StyleProp,
} from 'react-native';
import { styles } from './NewNativeViewStyle';

// Native component props interface
interface ExoPlayerViewProps {
  style?: StyleProp<ViewStyle>;
  source?: { uri: string };
  controllerEnabled?: boolean;
  resizeMode?: string;
  autoPlay?: boolean;
  paused?: boolean;
  muted?: boolean;
  repeat?: boolean;
  seekTo?: number;
  onError?: (event: string| object) => void;
}

const ExoPlayerView = requireNativeComponent<ExoPlayerViewProps>('ExoPlayerView');

interface VideoPlayerProps {
  source: { uri: string };
  posterUrl?: string;
  controllerEnabled?: boolean;
  style?: string | StyleProp<ViewStyle>;
  movieId?: string;

  autoPlay?: boolean;          // ✅ added
  paused?: boolean;            // ✅ added (optional)
  muted?: boolean;
  repeat?: boolean;
  resizeMode?: 'stretch' | 'contain' | 'cover';
  seekTo?: number;             // ✅ added for seeking

  onLoad?: (data: { duration: number }) => void;
  onError?: (error: { error: string }) => void;
  onPlayPause?: (isPlaying: boolean) => void;
  onEnd?: () => void;
  onProgress?: (data: { currentTime: number; duration: number }) => void; // ✅ added
  onSeek?: (position: number) => void; // ✅ added
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({
  source,
  posterUrl,
  controllerEnabled = true,
  style,
  movieId,
  autoPlay = true,
  paused = false,
  muted = false,
  repeat = true,
  resizeMode = 'stretch',
  seekTo,
  onLoad,
  onError,
  onPlayPause,
  onEnd,
  onProgress,
  onSeek,
  ...props
}) => {
  const [showPoster, setShowPoster] = useState(true);
  const [isVideoLoaded, setIsVideoLoaded] = useState(false);

  const posterOpacity = useRef(new Animated.Value(1)).current;
  const playerRef = useRef(null);

  const uri = String(source?.uri || '');

  // ✅ Reset when URI changes
  useEffect(() => {
    setShowPoster(true);
    setIsVideoLoaded(false);
    posterOpacity.setValue(1);
  }, [uri, posterOpacity]);

  const hidePoster = useCallback(() => {
    Animated.timing(posterOpacity, {
      toValue: 0,
      duration: 350,
      useNativeDriver: true,
    }).start(() => setShowPoster(false));
  }, [posterOpacity]);

  // ✅ Native events
  useEffect(() => {
    const readyListener = DeviceEventEmitter.addListener('onVideoReady', (event) => {
      setIsVideoLoaded(true);
      if (event?.duration != null) {
        onLoad?.({ duration: Number(event.duration) });
      }
      hidePoster();
    });

    const playPauseListener = DeviceEventEmitter.addListener('onPlayPause', (event) => {
      if (event?.isPlaying !== undefined) onPlayPause?.(!!event.isPlaying);
    });

    const endListener = DeviceEventEmitter.addListener('onVideoEnd', () => onEnd?.());

    // ✅ Progress listener for video progress updates
    const progressListener = DeviceEventEmitter.addListener('onVideoProgress', (event) => {
      if (event?.currentTime != null && event?.duration != null) {
        onProgress?.({
          currentTime: Number(event.currentTime),
          duration: Number(event.duration),
        });
      }
    });

    return () => {
      readyListener.remove();
      playPauseListener.remove();
      endListener.remove();
      progressListener.remove();
    };
  }, [hidePoster, onLoad, onPlayPause, onEnd, onProgress]);

  const onNativeError = (event: string | object) => {
    const eventData = event?.nativeEvent || event;
    onError?.({ error: eventData?.error || 'Unknown video error' });
  };

  if (!uri) {
    return (
      <View style={[styles.container, style]}>
        {posterUrl ? (
          <Image source={{ uri: posterUrl }} style={styles.poster} resizeMode="stretch" />
        ) : null}
      </View>
    );
  }

  return (
    <View style={[styles.container, style]}>
      <View style={styles.videoContainer}>
        {/* Poster */}
        {showPoster && posterUrl && !isVideoLoaded && (
          <Animated.Image
            source={{ uri: posterUrl }}
            style={[styles.poster, { opacity: posterOpacity }]}
            resizeMode="stretch"
          />
        )}

        {Platform.OS === 'android' ? (
          <ExoPlayerView
            ref={playerRef}
            style={styles.video}
            // ✅ IMPORTANT: keep it simple. Native ko exact uri string milni chahiye.
            source={{ uri }}

            controllerEnabled={controllerEnabled}
            resizeMode={resizeMode}

            // ✅ playback props (native side me handle karna hoga)
            autoPlay={autoPlay}
            paused={paused}
            muted={muted}
            repeat={repeat}
            
            // ✅ Seek to position in seconds
            seekTo={seekTo}

            onError={onNativeError}
            {...props}
          />
        ) : (
          <View style={styles.unsupportedContainer}>
            {posterUrl ? (
              <Image source={{ uri: posterUrl }} style={styles.poster} resizeMode="stretch" />
            ) : null}
          </View>
        )}
      </View>
    </View>
  );
};

export default VideoPlayer;
