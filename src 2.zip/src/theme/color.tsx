 
  export const Color = {

    // real file
    // darkGrey:'#1a1a1a',
    darkGrey:'#1A1A1A',
    background: "#000000",
    primary:"#008AC9",
graybackGround:"#1A1A1A",
    text: "#FFFFFF",
    // real file 
    placeHolder:"#767676",
primary600:"#006c9d",
    modalBg:"#1a1a1a",
grey:"#2D2D2E",
grey700:"#28292A",
yellow1:"#F0D241",
    // real file 
    buttonBackground: "#ff6347",
    whiteText:"#FFFFFF",
    textGray:"#8C8C8C",
    green:"#2AA147",
    lightGrayText:"#CDCDCD",
 lightPrimary:"#00A8F5",
    blueprimary: "#00A8F5",
    red:"#CA462A",
    yellow:"#a48b0d",
  modalTransperant:'rgba(8, 8, 8, 0.9)',
  orang:"#c34429",
  headerTransparent: 'rgba(0, 0, 0, 0.8)',
  grey200:'#E4E4E4',
  geoupContainerColor:"#1b1f21",
  settingFreatureSvg:'#4EC8FF',
  settingFreatureSvgTras:'rgba(7, 12, 17, 1)',
  TransperantColor:'rgba(255, 255, 255, 0)',


    // shimmerColors={['#181818ff', '#464545ff', '#181717ff']}
  };
