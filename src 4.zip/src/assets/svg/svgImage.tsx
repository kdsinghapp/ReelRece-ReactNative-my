import Pause from "./Pause";
import Play from "./Play";
import Second from "./Second";
import Timeplay from "./Timeplay";



export default{
    Play ,
    Pause ,
    Timeplay ,
    Second
}